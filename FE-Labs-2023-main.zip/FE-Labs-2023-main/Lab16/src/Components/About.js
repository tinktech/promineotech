import React from 'react';

export default function About() {
	
		return <h2>About</h2>;
}


