 *         .map hint: {this.customersArray.map((customer, index) => (
 *                    //return your elements here
 *                    //Each <tr> will also need a key prop with a unique value.
 *                    ))}